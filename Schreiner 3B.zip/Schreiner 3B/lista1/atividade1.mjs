 import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade1(){

    let numero;
    let result
let numerodigitado = prompt("digite o número");
 
if (numerodigitado < 10 ) {
    result="seu numero é par"
}
if (numerodigitado %2 === 0)
result= ("seu numero é par")


else {
    result=("seu numero é impar")
}
 
console.log(result)

}
 

 

 
 