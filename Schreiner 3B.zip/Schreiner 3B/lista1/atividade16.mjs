import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade16 ( ){

let numeros = []
    let numero;

    while (true) {
        numero = parseInt(prompt("Digite um número (ou -1 para sair): "));

        if (numero === -1) {
            break;
        }

        numeros.push(numero);
    }

    if (numeros.length > 0) {
        let soma = 0;
        let maior = numeros[0];
        let menor = numeros[0];

        for (let num of numeros) {
            soma += num;
            if (num > maior) maior = num;
            if (num < menor) menor = num;
        }

        let media = soma / numeros.length;

        console.log(`Média: ${media}`);
        console.log(`Maior valor: ${maior}`);
        console.log(`Menor valor: ${menor}`);
    } else {
        console.log("Nenhum número foi inserido.");
    }

    
}