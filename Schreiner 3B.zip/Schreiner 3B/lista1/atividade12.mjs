import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade12(){
 let numeroAleatorio1
 let numeroAleatorio2
 let numeroAleatorio3
 let numeroAleatorio4
 let numeroAleatorio5

let resultado1 = Math.floor(Math.random()*50)
let resultado2 = Math.floor(Math.random()*50)
let resultado3 = Math.floor(Math.random()*50)
let resultado4 = Math.floor(Math.random()*50)
let resultado5 = Math.floor(Math.random()*50)
let num1 = Number(prompt(" digite o numero"))
let num2 = Number(prompt("digite o numero"))
let num3 = Number(prompt("digite o numero"))
let num4 = Number(prompt("digite o numero"))
let num5 = Number(prompt("digite o numero"))
let cont = 0


if (num1 == resultado1) {
   console.log('esse nao é o numero')}
 ;
 cont++

if (num2 == resultado2) {
    console.log('esse nao é o numero')
 };

 if (num3 == resultado3) {
    console.log(' esse nao é o numero')
 };
cont++
 if (num4 == resultado4) {
    console.log(' esse nao é o numero')
 };
cont++
 if (num5 == resultado5) {
    console.log(' esse nao é o numero')
 };

 console.log

 if (num1 == numeroAleatorio1) {
    resultado1 = "Você acertou"
   cont++
} if (num2 == numeroAleatorio2) {
   resultado2 = "Você acertou"
   cont++
} if (num3 == numeroAleatorio3) {
   result3 = "Você acertou"
   cont++
} if (num4 == numeroAleatorio4) {
   resultado4 = "Você acertou"
   cont++
} if (num5 == numeroAleatorio5) {
   resultado5 = "Você acertou"
   cont++
} 


   console.log("Voce acertou: "+ cont + " números")

}
