import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade2(){



let ano= 2025
let colegio= 'CEEP'
let turma='3B'
console.log(' A turma "' + turma + "' do colégio "  + colegio +  " é a melhor de " + ano +'.' )


}