import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade3(){
 
let result;
let numero;

while (numero != 23) {
    numero = prompt("digite um numero")
    if (numero == 23) {
        result = ("seu numero é 23" + numero)
    }
    else {
        result = ("seu numero nao é 23")
    }
    console.log(result)
}
}





