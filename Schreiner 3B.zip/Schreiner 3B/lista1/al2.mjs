import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function al2(){
let numero;
 numero =  prompt ("escreva um numero");
 console.log((numero)*2)}