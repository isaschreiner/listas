import promptSync from 'prompt-sync'
const prompt = promptSync();
export default function atividade15( ){

let num = Number(prompt(" digite o numero"))
let num2 = Number(prompt("digite o numero"))

while(num<num2)
if (num < 2) {
    console.log("seu numero é primo: ")
}
else {
    let i = 2
    let eprimo = true
    while (i < num) {
        if ((num % i) == 0) {
            eprimo = false
        }
        i++

    }
    if (eprimo) {
         console.log("seu numero é primo:  "+num)
       

    }
    else {  


        console.log("seu numero nao é primo "+num)    }
num++
}
}