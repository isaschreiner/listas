import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade7(){
 let num = parseInt(Math.random()*11);

 let num2 = parseInt(prompt("Digite um número de 1 a 10: "));

 while (num2 != num) {
    num2 = prompt("Não é esse: ");
 };
 if (num2 == num) {
    console.log('É esse o número')
 };
}