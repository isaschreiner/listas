import PromptSync from "prompt-sync";
const prompt = PromptSync();

export default function atividade17() {

    const andarAtual = parseInt(prompt("Informe o andar atual (0 a 10): "));
    const andarDesejado = parseInt(prompt("Informe o andar desejado (0 a 10): "));


    if (andarAtual < 0 || andarAtual > 10 || andarDesejado < 0 || andarDesejado > 10) {
        console.log("Andar inválido! Por favor, escolha andares entre 0 e 10.");
        return;
    }

    if (andarAtual === andarDesejado) {
        console.log("O elevador já está no andar desejado.");
        return;
    }


    if (andarDesejado > andarAtual) {
        console.log("Elevador subindo:");
        for (let andar = andarAtual + 1; andar <= andarDesejado; andar++) {
            console.log(`Subindo para o andar ${andar}...`);
        }
    } else {
        console.log("Elevador descendo:");
        for (let andar = andarAtual - 1; andar >= andarDesejado; andar--) {
            console.log(`Descendo para o andar ${andar}...`);
        }
    }

    console.log("Chegou ao andar desejado!");
}