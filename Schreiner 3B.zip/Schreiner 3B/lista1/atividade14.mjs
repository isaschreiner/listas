import promptSync from 'prompt-sync'
const prompt = promptSync();
export default function atividade14 ( ){


let numu = Number(0)
let numc = getRandomIntInclusive(0, 10)
let escolha
let resultado = Number(0)

console.log('par ou impar')
escolha = prompt('P=Par I=Impar :')

console.log(escolha == 'P' ? "Você é par\no computador é impar" : "Você é impar\no computador é par")

numu = Number(prompt('Agora digite seu número(o número deve ser de 0 a 10): '))
console.log('o chute do computador é :' + numc)
resultado = numu + numc
console.log('o resultado é ' + resultado)

if ((resultado % 2) == 0) {
    console.log(escolha == 'P' ? 'Você ganhou :)' : 'Você perdeu :(')
} else {
    console.log(escolha == 'P' ? 'Você perdeu :(' : 'Você ganhou :)')
}



function getRandomIntInclusive(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
}