import PromptSync from "prompt-sync";
const prompt = PromptSync();

  
  

import al1 from './al1.mjs'
import al2 from './al2.mjs'
import al3 from './al3.mjs'
import al4 from './al4.mjs'
import at1 from './at1.mjs'
import atividade1 from './atividade1.mjs'
import atividade2 from './atividade2.mjs'
import atividade3 from './atividade3.mjs'
import atividade6 from './atividade6.mjs'
import atividade7 from './atividade7.mjs'
import atividade8 from './atividade8.mjs'
import atividade9 from './atividade9.mjs'
import atividade10 from './atividade10.mjs'
import atividade11 from './atividade11.mjs'
import atividade12 from './atividade12.mjs'
import atividade13 from './atividade13.mjs'
import atividade14 from './atividade14.mjs'
import atividade15 from './atividade15.mjs'
import atividade16 from './atividade16.mjs'
import atividade17 from "./atividade17.mjs";
import atividade18 from "./atividade18.mjs";


let opcao;

console.log(" __________________________________________")
console.log("|                                          |")
console.log("|     Qual tela você quer entrar?          |")
console.log("|                                          |")
console.log("| 1 - Atividade 1                          |")
console.log("|                                          |")
console.log("| 2 - Atividade 2                          |")
console.log("|                                          |")
console.log("| 3 - Atividade 3                          |")
console.log("|                                          |")
console.log("| 4 - Atividade 4                          |")
console.log("|                                          |")
console.log("| 5 - Atividade 5                          |")
console.log("|                                          |")
console.log("| 6 - Atividade 6                          |")
console.log("|                                          |")
console.log("| 7 - Atividade 7                          |")
console.log("|                                          |")
console.log("| 8 - Atividade 8                          |")
console.log("|                                          |")
console.log("| 9 - Atividade 9                          |")
console.log("|                                          |")
console.log("| 10 - Atividade 10                        |")
console.log("|                                          |")
console.log("| 11 - Atividade 11                        |")
console.log("|                                          |")
console.log("| 12 - Atividade 12                        |")
console.log("|                                          |")
console.log("| 13 - Atividade 13                        |")
console.log("|                                          |")
console.log("| 14 - Atividade 14                        |")
console.log("|                                          |")
console.log("| 15 - Atividade 15                        |")
console.log("|                                          |")
console.log("| 16 - Atividade 16                        |")
console.log("|                                          |")
console.log("| 17 - Atividade 17                        |")
console.log("|                                          |")
console.log("| 18 - Atividade 18                        |")
console.log("|__________________________________________|")

opcao = parseInt(prompt("Escolha a sua Tela: "))


if (opcao == 1) {
    al1()
}
if (opcao == 2) {
    al2()
}
if (opcao == 3) {
    al3()
}
if (opcao == 4) {
    al4()
}
if (opcao == 5) {
    at1()

}
if (opcao == 6) {
    atividade1()

}
if (opcao == 7) {
    atividade2()

}
if (opcao == 8) {
    atividade3()

}
if (opcao == 9) {
    atividade6()

}if (opcao == 10) {
    atividade7()

}
if (opcao == 11) {
    atividade8()

}
if (opcao == 12) {
    atividade9()

}
if (opcao == 13) {
    atividade10()

}
if (opcao == 14) {
    atividade11()

}
if (opcao == 15) {
    atividade12()

}
if (opcao == 16) {
    atividade13()

}if (opcao == 17) {
    atividade14()

} if (opcao == 18) {
    atividade15()

}
if (opcao == 19) {
    atividade16()

}
if (opcao == 20) {
    atividade17()

}
if (opcao == 21) {
    atividade18()

}



