import promptSync from 'prompt-sync';
const prompt = promptSync();

export default function at1() {

    console.log("Algoritmo da atividade 1")

}


