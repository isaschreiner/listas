import promptSync from 'prompt-sync'
const prompt = promptSync();
export default function atividade13( ){ 
let i=Number(0)
console.log('contagem regeressiva')
i=prompt('digite um número para começar a contagem: ')
while(i>-1){
    console.log(i)
    i--

}
if(i=-1){
    console.log('game over')
    
}

}




