import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function al3(){
let numero1 = Number ( prompt("digite o primeiro numero"));
let numero2 = Number ( prompt("digite o segundo numero"));
 
console.log (numero1)
console.log (numero2-numero1)
console.log (numero1/ numero2)
console.log (numero2*numero1)
}