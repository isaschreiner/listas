
import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade10(){


 let numero = Number(0)
let total = Number (1)
 let i=0;
while (i<5){
    numero = parseInt (prompt("Digite o seu numero: "))
    if ((numero%2)==0){
        total=total*numero
    }
    i++
}
console.log("O resultado da multiplicação dos pares é: "+ total)
}