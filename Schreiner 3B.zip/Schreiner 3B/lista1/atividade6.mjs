import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade6(){
 
 
 
 let soma
 
 
 
 let i = 2
soma = 0
while (i<=100) {
    console.log ("numero do contador é:"+ i)
    soma = soma + i
    console.log ("numero que esta sendo somado é:"+ i)
i= i+2
}
}
 
 
