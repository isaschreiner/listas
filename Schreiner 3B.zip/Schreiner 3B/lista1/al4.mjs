import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function al4(){
let nome=(prompt("Digite o seu nome: "))
let idade=(prompt("Digite a sua idade: "))
let cidade=(prompt("Digite a sua cidade: "))

console.log ("O "+ nome + " tem "+ idade + " anos e mora em " + cidade)}