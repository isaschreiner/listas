import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade18 ( ){
    function corrida(distancia) {
        let posicaoCorredor1 = 0;
        let posicaoCorredor2 = 0;
    
        console.log(`Iniciando a corrida de ${distancia} unidades!`);

        while (posicaoCorredor1 < distancia && posicaoCorredor2 < distancia) {
        
            let velocidadeCorredor1 = Math.floor(Math.random() * 5) + 1; 
            let velocidadeCorredor2 = Math.floor(Math.random() * 5) + 1; 
    
           
            posicaoCorredor1 += velocidadeCorredor1;
            posicaoCorredor2 += velocidadeCorredor2;
    
           
            console.log(`Corredor 1: ${posicaoCorredor1} | Corredor 2: ${posicaoCorredor2}`);
        }
    
     
        if (posicaoCorredor1 >= distancia && posicaoCorredor2 >= distancia) {
            console.log("Empate! Ambos os corredores cruzaram a linha de chegada ao mesmo tempo.");
        } else if (posicaoCorredor1 >= distancia) {
            console.log("Corredor 1 venceu!");
        } else {
            console.log("Corredor 2 venceu!");
        }
    }
   
    const distanciaDaCorrida = 20;
    corrida(distanciaDaCorrida); }