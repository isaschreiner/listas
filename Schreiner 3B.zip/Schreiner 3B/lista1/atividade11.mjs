import PromptSync from 'prompt-sync';
const prompt = PromptSync();

export default function atividade11(){
let somaFrase = ""
let frase
 let i=0;
while (i<3){
    i++
    frase = (prompt("Digite a sua frase: "))
    somaFrase=somaFrase+ " " + frase
}
console.log (somaFrase)
}
