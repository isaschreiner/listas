 //  PT1 Pedir p inserir 10 num
// PT2  EXIBIBIR MAIOR NUMERO DIGITADO

import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade8(){
let num;
let i = 1
let maior = 0;

while (i<11) {
    num = parseInt(prompt("Digite um número: "));
    if (num>maior) {
        maior = num
    }
    i = i+1
}
console.log ('o maior é: '+ maior);
}
