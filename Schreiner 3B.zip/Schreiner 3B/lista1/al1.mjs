import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function al1(){
let nome = 'dez';
let number = 10;
let boolean = false;

console.log( typeof(nome) + "o nome é " + nome);
console.log( typeof (number) + "o numero é " + number);
console.log(typeof (boolean) + "o boolean é " + boolean);
}