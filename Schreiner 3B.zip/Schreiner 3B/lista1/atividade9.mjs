import PromptSync from "prompt-sync";
const prompt = PromptSync();
export default function atividade9(){
let num = Number
let soma = 0
let i = 0

while (i<10){

    num = parseInt(prompt ("insira 10 numeros"))
 soma= soma+num
 console.log("a soma do numero é: " + soma)
    i++

}
}