import PromptSync from "prompt-sync";

 const prompt = PromptSync()
 export default function at1 ( ){

let nota = Number (prompt("digite a nota: "))
let nota2= Number (prompt("digite a nota: "))
let nota3= Number (prompt("digite a nota: "))
let result
 

let media= (nota+nota2+nota3/3)



if 
   (media<70){
   
    console.log("você passou, parabéns!!!")


}

else {

    console.log("você não passou, que pena")


}
     

 }
