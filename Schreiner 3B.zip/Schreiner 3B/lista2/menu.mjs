import PromptSync from "prompt-sync";
const prompt = PromptSync();

  
  

import at1 from './at1.mjs'
import at2 from './at2.mjs'
import at3 from './at3.mjs'
import at4 from './at4.mjs'
import at5 from './at5.mjs'
import at6 from './at6.mjs'
import at7 from './at7.mjs'


let opcao;

console.log(" __________________________________________")
console.log("|                                          |")
console.log("|     Qual tela você quer entrar?          |")
console.log("|                                          |")
console.log("| 1 - Atividade 1                          |")
console.log("|                                          |")
console.log("| 2 - Atividade 2                          |")
console.log("|                                          |")
console.log("| 3 - Atividade 3                          |")
console.log("|                                          |")
console.log("| 4 - Atividade 4                          |")
console.log("|                                          |")
console.log("| 5 - Atividade 5                          |")
console.log("|                                          |")
console.log("| 6 - Atividade 6                          |")
console.log("|                                          |")
console.log("| 7 - Atividade 7                          |")
console.log("|__________________________________________|")



opcao = parseInt(prompt("Escolha a sua Tela: "))


if (opcao == 1) {
    at1()
}
if (opcao == 2) {
    at2()
}
if (opcao == 3) {
    at3()
}
if (opcao == 4) {
    at4()
}
if (opcao == 5) {
    at5()

}
if (opcao == 6) {
    at6()

}
if (opcao == 7) {
    at7()

}