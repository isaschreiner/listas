import PromptSync from 'prompt-sync';
const prompt = PromptSync();

export default function at3 ( ){

console.log ("Vamos Calcular a média de idades dos alunos!")
console.log ("--------------------------------------------")
let alunos=Number(prompt("Quantos alunos ha na turma? "))
let i=0
let idades=0
let result
let soma = 0

while(i < alunos){
idades=Number(prompt("Agora digite a idade de cada aluno "))
i++
soma= idades + soma
}

console.log("A média das idades é: "+ soma/alunos)

}