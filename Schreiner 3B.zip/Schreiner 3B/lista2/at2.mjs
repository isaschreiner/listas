import PromptSync from "prompt-sync";

 const prompt = PromptSync()
 export default function at2 ( ){

let nota = Number (prompt("digite a nota: "))
let nota2= Number (prompt("digite a nota: "))
let nota3= Number (prompt("digite a nota: "))
let result
 
let pond = (nota*2)
let pond2 = (nota2*3)
let pond3 = (nota3*5)





let media= (pond+pond2+pond3/10)



if 
   (media<60){
   
    console.log("você passou, parabéns!!!")


}

else {

    console.log("você não passou, que pena")


}
 }