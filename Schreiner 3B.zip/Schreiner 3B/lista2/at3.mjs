 import PromptSync from "prompt-sync";
 const prompt = PromptSync()
 export default function at3 ( ){
  
 
console.log("calculando a média dos aluno ;) - creditos: Gustavo Camargo")
console.log("                                                           ")
console.log("-----------------------------------------------------------")
console.log(" notas do aluno tatiana")
console.log("                                                           ")
 
let aluno1nota1 = Number (prompt("digite a nota: "))
 let aluno1nota2 = Number (prompt("digite a nota: "))
 let aluno1nota3 = Number ( prompt("digite a nota: "))
let media
let media2

console.log(" notas do aluno robson")
 let aluno2nota1 = Number (prompt("digite a nota: "))
 let aluno2nota2 = Number (prompt("digite a nota: "))
 let aluno2nota3 = Number (prompt("digite a nota: "))




 media=((aluno1nota1+aluno1nota2+aluno1nota3)/3)
 media2=((aluno2nota1+aluno2nota2+aluno2nota3)/3)

console.log(media)
console.log(media2)

 if (media>media2){
    console.log("parabens pelas notas, são iguais!")

 }
 if (media<media2){
    console.log("que pena!") }
if (media==media2){
    console.log(" empate, os dois tem a mesma média")

}
 }
