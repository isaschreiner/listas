let listaexemplo = []
listaexemplo

listaexemplo.push(25)
listaexemplo.push(72)
listaexemplo.push(55)
listaexemplo.push(30)

console.log(listaexemplo)


let i = 0
while(i<listaexemplo.length){}