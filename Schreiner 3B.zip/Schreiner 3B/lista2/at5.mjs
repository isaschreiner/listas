import PromptSync from "prompt-sync";
const prompt = PromptSync()
export default function at5( ){

let i = 0
let days = 7
let temp
let soma = 0
let temps = []


while (i < days) {

    temp = Number(prompt("digite a temperatura que estava esse dia: "))
    temps.push(temp)

    soma += temp

    i++
}

let media = soma / 7 

i=0
while (i<temps.length){

    if(temps[i] > media){
console.log((1+i)  + " é maior do que a media")
console.log("a media de temperatura é : " + media)

   
   
    }

i++
}

console.log(temps)
}