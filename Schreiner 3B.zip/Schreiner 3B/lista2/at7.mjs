import PromptSync from "prompt-sync";
const prompt = PromptSync()
 
export default function at7 ( ){

    let i = 0
    let days = 5
    let media = 100
    let soma = 0
    let venda
    let temps = []
    
    console.log("vendas diarias, calculando a media")
    console.log("                                   ")
    console.log("-----------------------------------")
    while (i < days) {
    
        venda = Number(prompt("digite o numero de vendas nesse estava esse dia: "))
        temps.push(venda)
    
        soma += venda
    
        i++
    }
     media = soma / 5 
    
    i=0
    while (i<venda.length){
    
        if(venda[i] > media){
    console.log((1+i)  + " é maior do que a media")
    console.log("a media de vendas é : " + media)
    
       
       
        }
    
    i++
    }
    
    console.log( "a media diaria que está baixa é do dia: "  + venda)
    console.log( "a media é: "  + media)
    
}
