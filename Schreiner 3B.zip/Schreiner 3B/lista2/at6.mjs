import PromptSync from 'prompt-sync';
const prompt = PromptSync();
export default function at6 ( ){

console.log ("Vamos Calcular a média de salarios !")
console.log ("--------------------------------------------")
let funcionarios =Number(prompt("Quantos funcionarios ha na empresa? "))
let i=0
let salario=0
let lista =[]
let a
 
let soma = 0
let media
while(i < funcionarios){
salario=Number(prompt("Agora digite o salario "))
i++
soma= salario + soma
}

console.log("A média salarial é: "+ soma/funcionarios)

i=0
while(i<lista.length){
   if(lista[i]>media){
    console.log("O Salario " + (i + 1) +" é maior que a média!")
    a++
   }
   
    i++
}
console.log(a + " Funcionarios recebem acima da média") 

}